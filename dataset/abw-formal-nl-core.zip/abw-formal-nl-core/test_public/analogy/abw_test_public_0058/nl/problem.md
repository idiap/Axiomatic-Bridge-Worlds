# Problem

The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Public Vocabulary

## Rules

## Public Theories

### Theory Left
#### Vocabulary
- Object kind: mav.
- Named object: mav-0 is a mav object.
- Named object: mav-1 is a mav object.
- Operation: shift takes a mav object and returns a mav object.
- Operation: lift takes a mav object and returns a mav object.
- Operation: glide takes a mav object and returns a mav object.
- Operation: turn takes a mav object and returns a mav object.
- Relation: LP0 can hold of a mav object.
- Relation: LP1 can hold of a mav object.
- Relation: LP2 can hold of a mav object.
- Relation: LP3 can hold of a mav object.
#### Rules
- If LP0 holds of x, then LP1 holds of the shift of x.
- If LP1 holds of x, then LP2 holds of the lift of x.
- If LP2 holds of x, then LP3 holds of the glide of x.
- If LP3 holds of x, then LP0 holds of the turn of x.

### Theory Right
#### Vocabulary
- Object kind: ren.
- Named object: ren-0 is a ren object.
- Named object: ren-1 is a ren object.
- Operation: seal takes a ren object and returns a ren object.
- Operation: flick takes a ren object and returns a ren object.
- Operation: shift-1 takes a ren object and returns a ren object.
- Operation: lift-1 takes a ren object and returns a ren object.
- Relation: RP0 can hold of a ren object.
- Relation: RP1 can hold of a ren object.
- Relation: RP2 can hold of a ren object.
- Relation: RP3 can hold of a ren object.
#### Rules
- If RP0 holds of y, then RP1 holds of the seal of y.
- If RP1 holds of y, then RP2 holds of the flick of y.
- If RP2 holds of y, then RP3 holds of the shift-1 of y.
- If RP3 holds of y, then RP0 holds of the lift-1 of y.

## Task
Infer a structure-preserving mapping between the public theories.
Then use that mapping to transport visible source-theory theorems into the target theory.
