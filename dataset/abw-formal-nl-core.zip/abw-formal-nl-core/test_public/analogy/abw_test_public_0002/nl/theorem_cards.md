# Theorem Cards

## Visible Theorems

## Theory Theorems

### Theory Left
- **left_cycle_0**: If LP0 holds of x, then LP0 holds of the turn of the glide of the lift of the shift of x.
- **left_cycle_1**: If LP1 holds of x, then LP1 holds of the shift of the turn of the glide of the lift of x.

### Theory Right
