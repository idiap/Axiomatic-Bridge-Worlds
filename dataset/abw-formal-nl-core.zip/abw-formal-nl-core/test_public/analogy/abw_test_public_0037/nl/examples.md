# Examples

## Visible Facts

## Visible Targets

## Theory Facts

### Theory Left
- LP0 holds of mav-0.
- LP0 holds of mav-1.

### Theory Right
- RP0 holds of ren-0.
- RP0 holds of ren-1.
