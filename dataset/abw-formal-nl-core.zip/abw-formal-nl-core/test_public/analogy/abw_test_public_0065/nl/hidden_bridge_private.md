# Hidden Bridge

- morphism M : Left -> Right {
  L0 -> R0
  LD0 -> RD0
  LD1 -> RD1
  LD2 -> RD2
  LP0 -> RP0
  LP1 -> RP1
  LP2 -> RP2
  LP3 -> RP3
  l0 -> r0
  l1 -> r1
  l2 -> r2
  ldf0 -> rdf0
  ldf1 -> rdf1
  ldf2 -> rdf2
  lf0 -> rf0
  lf1 -> rf1
  lf2 -> rf2
  lf3 -> rf3
}
