# Theorem Cards

## Visible Theorems

## Theory Theorems

### Theory Left
- **left_cycle_0**: If LP0 holds of x, then LP0 holds of the lift of the shift of x.

### Theory Right
