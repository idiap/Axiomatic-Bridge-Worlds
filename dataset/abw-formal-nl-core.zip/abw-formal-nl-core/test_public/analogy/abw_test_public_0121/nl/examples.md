# Examples

## Visible Facts

## Visible Targets

## Theory Facts

### Theory Left
- LP0 holds of mav-0.
- LP0 holds of mav-1.
- LD0 holds of mav-0.
- LD1 holds of mav-0.

### Theory Right
- RP0 holds of ren-0.
- RP0 holds of ren-1.
- RD0 holds of ren-0.
- RD1 holds of ren-0.
