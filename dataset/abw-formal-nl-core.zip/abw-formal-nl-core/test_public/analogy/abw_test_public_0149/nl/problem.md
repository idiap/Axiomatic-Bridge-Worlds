# Problem

The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Public Vocabulary

## Rules

## Public Theories

### Theory Left
#### Vocabulary
- Object kind: mav.
- Named object: mav-0 is a mav object.
- Named object: mav-1 is a mav object.
- Named object: mav-2 is a mav object.
- Operation: shift takes a mav object and returns a mav object.
- Operation: lift takes a mav object and returns a mav object.
- Relation: LP0 can hold of a mav object.
- Relation: LP1 can hold of a mav object.
#### Rules
- If LP0 holds of x, then LP1 holds of the shift of x.
- If LP1 holds of x, then LP0 holds of the lift of x.

### Theory Right
#### Vocabulary
- Object kind: ren.
- Named object: ren-0 is a ren object.
- Named object: ren-1 is a ren object.
- Named object: ren-2 is a ren object.
- Operation: glide takes a ren object and returns a ren object.
- Operation: turn takes a ren object and returns a ren object.
- Relation: RP0 can hold of a ren object.
- Relation: RP1 can hold of a ren object.
#### Rules
- If RP0 holds of y, then RP1 holds of the glide of y.
- If RP1 holds of y, then RP0 holds of the turn of y.

## Task
Infer a structure-preserving mapping between the public theories.
Then use that mapping to transport visible source-theory theorems into the target theory.
