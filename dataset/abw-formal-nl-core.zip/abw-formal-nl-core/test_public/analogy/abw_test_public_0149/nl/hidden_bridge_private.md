# Hidden Bridge

- morphism M : Left -> Right {
  L0 -> R0
  LP0 -> RP0
  LP1 -> RP1
  l0 -> r0
  l1 -> r1
  l2 -> r2
  lf0 -> rf0
  lf1 -> rf1
}
