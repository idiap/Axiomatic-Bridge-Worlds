# Examples

## Visible Facts
- A holds of mav-0.
- B holds of mav-0.
- Noise0 holds of mav-0.

## Visible Targets
- visible_stable_step: A holds of the shift of mav-0 and B holds of the shift of mav-0.
