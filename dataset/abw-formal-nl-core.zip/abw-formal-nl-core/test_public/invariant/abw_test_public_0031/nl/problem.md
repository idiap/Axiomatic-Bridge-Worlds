# Problem

The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Public Vocabulary
- Object kind: mav.
- Named object: mav-0 is a mav object.
- Named object: mav-1 is a mav object.
- Operation: shift takes a mav object and returns a mav object.
- Relation: A can hold of a mav object.
- Relation: B can hold of a mav object.
- Relation: C can hold of a mav object.

## Rules
- If A holds of x, then A holds of the shift of x.
- If B holds of x, then B holds of the shift of x.
- If C holds of x, then C holds of the shift of x.

## Task
Invent a reusable bridge concept that captures a repeated structural pattern in the public facts and theorems.
Then propose a lemma that makes deeper hidden targets cheaper to justify under the benchmark's proof budget.
