# Examples

## Visible Facts
- A holds of mav-0.
- B holds of mav-0.
- C holds of mav-0.
- D holds of mav-0.
- E holds of mav-0.
- Noise0 holds of mav-0.
- Noise1 holds of mav-0.
- Noise2 holds of mav-0.

## Visible Targets
- visible_stable_step: A holds of the shift of mav-0 and B holds of the shift of mav-0 and C holds of the shift of mav-0 and D holds of the shift of mav-0 and E holds of the shift of mav-0.
