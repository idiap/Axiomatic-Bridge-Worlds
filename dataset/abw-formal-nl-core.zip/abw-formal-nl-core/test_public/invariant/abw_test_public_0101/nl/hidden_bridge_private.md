# Hidden Bridge

- define StableBundle(x:S0) := A(x) & B(x) & C(x) & D(x) & E(x)
- lemma stable_step: forall x:S0. StableBundle(x) -> StableBundle(step(x))
