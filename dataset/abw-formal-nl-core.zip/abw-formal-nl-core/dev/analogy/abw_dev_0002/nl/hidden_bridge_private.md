# Hidden Bridge

- morphism M : Left -> Right {
  L0 -> R0
  LD0 -> RD0
  LP0 -> RP0
  LP1 -> RP1
  l0 -> r0
  ldf0 -> rdf0
  lf0 -> rf0
  lf1 -> rf1
}
