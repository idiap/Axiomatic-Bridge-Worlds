# Hidden Bridge

- morphism M : Left -> Right {
  L0 -> R0
  LP -> RP
  LQ -> RQ
  l0 -> r0
  lf -> rf
  lg -> rg
}
