# Gold Informal Solution

A strong solution identifies the symbol correspondence between the public theories and transports the source theorem family across it.
- Formal mapping: `M` from `Left` to `Right`.
