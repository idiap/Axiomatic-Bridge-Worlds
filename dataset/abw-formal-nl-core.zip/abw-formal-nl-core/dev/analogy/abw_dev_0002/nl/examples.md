# Examples

## Visible Facts

## Visible Targets

## Theory Facts

### Theory Left
- LP0 holds of mav-0.
- LD0 holds of mav-0.

### Theory Right
- RP0 holds of ren-0.
- RD0 holds of ren-0.
