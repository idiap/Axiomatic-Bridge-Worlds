# Problem

There are 0 synthetic object kinds in this world: .
The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Rules

## Task
Infer a structure-preserving mapping between the public theories.
Then use that mapping to transport visible source-theory theorems into the target theory.
