# Examples

## Visible Facts

## Visible Targets

## Theory Facts

### Theory Left
- LP0 holds of mav-0.

### Theory Right
- RP0 holds of ren-0.
