# Gold Informal Solution

A strong solution names the synchronized low-level state with one reusable predicate and advances it with one lemma.
- Formal definition: `define Aligned(x:S0, y:S1) := R(x, y) & P0(x) & P1(x) & P2(x) & P3(y) & P4(y)`
