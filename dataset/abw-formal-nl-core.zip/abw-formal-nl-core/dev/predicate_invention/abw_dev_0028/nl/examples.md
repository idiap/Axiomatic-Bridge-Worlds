# Examples

## Visible Facts
- P0 holds of mav-0.
- P1 holds of mav-0.
- P2 holds of mav-0.
- P0 holds of mav-1.
- P1 holds of mav-1.
- P2 holds of mav-1.
- P3 holds of ren-0.
- P4 holds of ren-0.
- P3 holds of ren-1.
- P4 holds of ren-1.
- R holds between mav-0 and ren-0.
- R holds between mav-1 and ren-1.
- N0 holds of mav-0.
- N1 holds of ren-0.
- N2 holds of mav-0.
- N3 holds of ren-0.

## Visible Targets
- visible_step_1: R holds between the shift of mav-0 and the lift of ren-0 and P0 holds of the shift of mav-0 and P1 holds of the shift of mav-0 and P2 holds of the shift of mav-0 and P3 holds of the lift of ren-0 and P4 holds of the lift of ren-0.
