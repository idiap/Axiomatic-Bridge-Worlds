# Problem

The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Public Vocabulary
- Object kind: mav.
- Object kind: ren.
- Named object: mav-0 is a mav object.
- Named object: mav-1 is a mav object.
- Named object: ren-0 is a ren object.
- Named object: ren-1 is a ren object.
- Operation: shift takes a mav object and returns a mav object.
- Operation: lift takes a ren object and returns a ren object.
- Relation: P0 can hold of a mav object.
- Relation: P1 can hold of a mav object.
- Relation: P2 can hold of a ren object.
- Relation: P3 can hold of a ren object.
- Relation: R can hold between a mav object and a ren object.

## Rules
- If P0 holds of x, then P0 holds of the shift of x.
- If P1 holds of x, then P1 holds of the shift of x.
- If P2 holds of y, then P2 holds of the lift of y.
- If P3 holds of y, then P3 holds of the lift of y.
- If R holds between x and y, then R holds between the shift of x and the lift of y.

## Task
Invent a reusable bridge concept that captures a repeated structural pattern in the public facts and theorems.
Then propose a lemma that makes deeper hidden targets cheaper to justify under the benchmark's proof budget.
