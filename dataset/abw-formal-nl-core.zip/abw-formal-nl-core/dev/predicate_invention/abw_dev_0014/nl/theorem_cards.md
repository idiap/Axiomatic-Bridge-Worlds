# Theorem Cards

## Visible Theorems
- **visible_pair_step**: If R holds between x and y and P0 holds of x and P1 holds of y, then R holds between the shift of x and the lift of y.
