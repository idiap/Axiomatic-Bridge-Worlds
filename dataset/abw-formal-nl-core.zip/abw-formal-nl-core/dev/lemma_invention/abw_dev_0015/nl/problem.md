# Problem

The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Public Vocabulary
- Object kind: mav.
- Named object: mav-0 is a mav object.
- Named object: mav-1 is a mav object.
- Operation: shift takes a mav object and returns a mav object.
- Operation: lift takes a mav object and returns a mav object.
- Operation: glide takes a mav object and returns a mav object.
- Relation: A can hold of a mav object.
- Relation: B can hold of a mav object.
- Relation: C can hold of a mav object.
- Relation: D can hold of a mav object.
- Relation: Noise0 can hold of a mav object.

## Rules
- If A holds of x, then B holds of the shift of x.
- If B holds of x, then C holds of the lift of x.
- If C holds of x, then D holds of the glide of x.
- If Noise0 holds of x, then Noise0 holds of the shift of x.

## Task
Invent a reusable shortcut lemma that collapses a repeated proof pattern in the public theory.
Then use it to make deeper hidden targets cheaper to justify under the benchmark's proof budget.
