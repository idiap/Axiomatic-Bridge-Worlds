# Gold Informal Solution

A strong solution packages the repeated low-level argument into one reusable lemma.
