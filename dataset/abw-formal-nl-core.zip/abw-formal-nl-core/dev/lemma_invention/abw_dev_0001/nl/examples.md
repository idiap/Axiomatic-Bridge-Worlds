# Examples

## Visible Facts
- A holds of mav-0.
- A holds of the shift of mav-0.

## Visible Targets
- visible_chain: D holds of the glide of the lift of the shift of mav-0.
