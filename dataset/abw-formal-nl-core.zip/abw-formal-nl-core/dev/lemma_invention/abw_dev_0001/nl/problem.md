# Problem

There are 1 synthetic object kinds in this world: mav.
The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Rules
- If A holds of x, then B holds of the shift of x.
- If B holds of x, then C holds of the lift of x.
- If C holds of x, then D holds of the glide of x.

## Task
Invent a reusable shortcut lemma that collapses a repeated proof pattern in the public theory.
Then use it to make deeper hidden targets cheaper to justify under the benchmark's proof budget.
