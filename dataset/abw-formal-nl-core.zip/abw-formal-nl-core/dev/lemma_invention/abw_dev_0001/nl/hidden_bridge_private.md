# Hidden Bridge

- lemma chain3: forall x:S0. A(x) -> D(h(g(f(x))))
