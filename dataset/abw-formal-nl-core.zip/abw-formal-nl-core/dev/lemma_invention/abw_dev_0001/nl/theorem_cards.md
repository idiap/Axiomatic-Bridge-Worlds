# Theorem Cards

## Visible Theorems
- **a_to_c**: If A holds of x, then C holds of the lift of the shift of x.
- **b_to_d**: If B holds of x, then D holds of the glide of the lift of x.
