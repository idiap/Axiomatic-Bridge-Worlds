# Theorem Cards

## Visible Theorems
- **prefix_shortcut**: If A holds of x, then C holds of the lift of the shift of x.
