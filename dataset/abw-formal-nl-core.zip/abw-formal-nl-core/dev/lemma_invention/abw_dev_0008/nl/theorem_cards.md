# Theorem Cards

## Visible Theorems
- **suffix_shortcut**: If B holds of x, then D holds of the glide of the lift of x.
