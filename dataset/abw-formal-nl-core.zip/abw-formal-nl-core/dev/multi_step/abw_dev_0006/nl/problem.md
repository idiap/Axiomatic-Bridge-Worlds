# Problem

There are 3 synthetic object kinds in this world: mav, ren, tal.
The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Rules
- If A holds of x, then A holds of the shift of x.
- If B holds of y, then B holds of the lift of y.
- If R holds between x and y, then R holds between the shift of x and the lift of y.
- If A holds of x and B holds of y and R holds between x and y, then C holds of glide(x, y).
- If C holds of z, then K holds of z.

## Task
Invent a reusable bridge concept that captures a repeated structural pattern in the public facts and theorems.
Then propose a lemma that makes deeper hidden targets cheaper to justify under the benchmark's proof budget.
