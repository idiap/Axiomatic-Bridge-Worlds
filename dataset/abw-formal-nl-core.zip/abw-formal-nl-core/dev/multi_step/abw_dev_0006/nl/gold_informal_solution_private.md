# Gold Informal Solution

A strong solution names the synchronized low-level state with one reusable predicate and advances it with one lemma.
- Formal definition: `define PairedGood(x:S0, y:S1) := A0(x) & A1(x) & A2(x) & B0(y) & B1(y) & B2(y) & R(x, y)`
- Formal definition: `define ConstructedGood(z:S2) := C0(z) & C2(z)`
