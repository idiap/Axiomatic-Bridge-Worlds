# Examples

## Visible Facts
- A holds of mav-0.
- B holds of ren-0.
- R holds between mav-0 and ren-0.

## Visible Targets
- visible_k_one: K holds of glide(the shift of mav-0, the lift of ren-0).
