# Examples

## Visible Facts
- A0 holds of mav-0.
- A1 holds of mav-0.
- A0 holds of mav-1.
- A1 holds of mav-1.
- B0 holds of ren-0.
- B1 holds of ren-0.
- B0 holds of ren-1.
- B1 holds of ren-1.
- R holds between mav-0 and ren-0.
- R holds between mav-1 and ren-1.
- Noise0 holds of mav-0.

## Visible Targets
- visible_k_one: C1 holds of the glide of the shift of mav-0 and the lift of ren-0.
