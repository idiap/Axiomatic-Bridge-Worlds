# Hidden Bridge

- define PairedGood(x:S0, y:S1) := A0(x) & A1(x) & B0(y) & R(x, y)
- define ConstructedGood(z:S2) := C0(z) & C1(z)
- lemma paired_step: forall x:S0 y:S1. PairedGood(x, y) -> PairedGood(f(x), g(y))
- lemma constructed_is_final: forall x:S0 y:S1. PairedGood(x, y) -> C1(h(x, y))
- lemma constructed_good_intro: forall x:S0 y:S1. PairedGood(x, y) -> ConstructedGood(h(x, y))
