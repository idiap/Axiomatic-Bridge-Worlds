# Problem

The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Public Vocabulary
- Object kind: mav.
- Object kind: ren.
- Object kind: tal.
- Named object: mav-0 is a mav object.
- Named object: mav-1 is a mav object.
- Named object: ren-0 is a ren object.
- Named object: ren-1 is a ren object.
- Operation: shift takes a mav object and returns a mav object.
- Operation: lift takes a ren object and returns a ren object.
- Operation: glide takes a mav object and a ren object and returns a tal object.
- Relation: A0 can hold of a mav object.
- Relation: A1 can hold of a mav object.
- Relation: A2 can hold of a mav object.
- Relation: B0 can hold of a ren object.
- Relation: B1 can hold of a ren object.
- Relation: B2 can hold of a ren object.
- Relation: C0 can hold of a tal object.
- Relation: C1 can hold of a tal object.
- Relation: C2 can hold of a tal object.
- Relation: R can hold between a mav object and a ren object.
- Relation: Noise0 can hold of a mav object.

## Rules
- If A0 holds of x, then A0 holds of the shift of x.
- If A1 holds of x, then A1 holds of the shift of x.
- If A2 holds of x, then A2 holds of the shift of x.
- If B0 holds of y, then B0 holds of the lift of y.
- If B1 holds of y, then B1 holds of the lift of y.
- If B2 holds of y, then B2 holds of the lift of y.
- If R holds between x and y, then R holds between the shift of x and the lift of y.
- If A0 holds of x and A1 holds of x and A2 holds of x and B0 holds of y and B1 holds of y and B2 holds of y and R holds between x and y, then C0 holds of the glide of x and y.
- If C0 holds of z, then C1 holds of z.
- If C1 holds of z, then C2 holds of z.
- If Noise0 holds of x, then Noise0 holds of the shift of x.

## Task
Invent a reusable bridge concept that captures a repeated structural pattern in the public facts and theorems.
Then propose a lemma that makes deeper hidden targets cheaper to justify under the benchmark's proof budget.
