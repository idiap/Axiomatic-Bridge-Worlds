# Theorem Cards

## Visible Theorems
- **visible_done_ab**: Done holds of the shift of the lift of x.
