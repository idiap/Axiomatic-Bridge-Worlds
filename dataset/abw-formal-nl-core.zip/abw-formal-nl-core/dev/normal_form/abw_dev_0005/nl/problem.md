# Problem

There are 1 synthetic object kinds in this world: mav.
The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Rules
- Done holds of the glide of x.

## Task
Invent a reusable bridge concept that captures a repeated structural pattern in the public facts and theorems.
Then propose a lemma that makes deeper hidden targets cheaper to justify under the benchmark's proof budget.
