# Gold Informal Solution

A strong solution names the synchronized low-level state with one reusable predicate and advances it with one lemma.
- Formal definition: `define Normal(x:T) := n(x) = x`
