# Hidden Bridge

- define Normal(x:T) := n(x) = x
- lemma done0_normal_shortcut: forall x:T. Marker0(x) -> Done0(n(x))
- lemma done1_normal_shortcut: forall x:T. Marker1(x) -> Done1(n(x))
