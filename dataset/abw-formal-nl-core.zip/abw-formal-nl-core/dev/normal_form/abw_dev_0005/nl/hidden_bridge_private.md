# Hidden Bridge

- define Normal(x:T) := n(x) = x
- lemma done_after_normalize: forall x:T. Normal(x) -> Done(x)
