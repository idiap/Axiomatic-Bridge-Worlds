# Examples

## Visible Facts

## Visible Targets
- visible_done_ab_z: Done holds of the shift of the lift of mav-0.
