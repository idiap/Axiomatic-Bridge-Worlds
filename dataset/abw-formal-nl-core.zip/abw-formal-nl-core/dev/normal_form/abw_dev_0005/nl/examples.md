# Examples

## Visible Facts
- Marker0 holds of mav-0.
- Marker1 holds of mav-0.

## Visible Targets
- visible_done_ab_z: Done0 holds of the shift of the lift of mav-0.
