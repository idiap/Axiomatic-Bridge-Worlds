# Problem

The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Public Vocabulary
- Object kind: mav.
- Named object: mav-0 is a mav object.
- Operation: shift takes a mav object and returns a mav object.
- Operation: lift takes a mav object and returns a mav object.
- Operation: glide takes a mav object and returns a mav object.
- Operation: turn takes a mav object and returns a mav object.
- Relation: Done0 can hold of a mav object.
- Relation: Ready0 can hold of a mav object.
- Relation: Marker0 can hold of a mav object.

## Rules
- The expression the shift of the glide of x rewrites to the turn of x.
- The expression the lift of the shift of x rewrites to the turn of x.
- The expression the glide of the lift of x rewrites to the turn of x.
- The expression the turn of the turn of x rewrites to the turn of x.
- If Marker0 holds of x, then Ready0 holds of the turn of x.
- If Ready0 holds of x, then Done0 holds of x.

## Task
Invent a reusable bridge concept that captures a repeated structural pattern in the public facts and theorems.
Then propose a lemma that makes deeper hidden targets cheaper to justify under the benchmark's proof budget.
