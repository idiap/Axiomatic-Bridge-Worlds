# Gold Informal Solution

A strong solution names the synchronized low-level state with one reusable predicate and advances it with one lemma.
- Formal definition: `define SameClass(x:S0, y:S0) := R(x, y)`
- Formal definition: `define Representative0(x:S0) := norm(x) = x`
