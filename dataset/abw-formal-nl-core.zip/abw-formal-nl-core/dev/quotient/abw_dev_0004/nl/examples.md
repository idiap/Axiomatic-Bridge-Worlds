# Examples

## Visible Facts
- Good0 holds of mav-0.
- R holds between mav-0 and mav-1.
- R holds between mav-0 and mav-2.
- Tag0 holds of mav-0.

## Visible Targets
- visible_good_norm: Good0 holds of the shift of mav-0.
