# Examples

## Visible Facts
- Good holds of mav-0.

## Visible Targets
- visible_good_norm: Good holds of the shift of mav-0.
