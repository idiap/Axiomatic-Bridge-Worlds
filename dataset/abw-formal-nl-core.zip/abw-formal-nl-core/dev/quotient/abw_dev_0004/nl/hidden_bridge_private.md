# Hidden Bridge

- define SameClass(x:S0, y:S0) := R(x, y)
- define Representative(x:S0) := norm(x) = x
- lemma good_transfer: forall x:S0. Good(x) -> Good(norm(x))
- lemma step_class: forall x:S0 y:S0. SameClass(x, y) -> SameClass(step(x), step(y))
