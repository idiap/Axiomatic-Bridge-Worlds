# Hidden Bridge

- define SameClass(x:S0, y:S0) := R(x, y)
- define Representative0(x:S0) := norm(x) = x
- lemma good0_norm_transfer: forall x:S0. Good0(x) -> Good0(norm(x))
- lemma step_class: forall x:S0 y:S0. SameClass(x, y) -> SameClass(step(x), step(y))
