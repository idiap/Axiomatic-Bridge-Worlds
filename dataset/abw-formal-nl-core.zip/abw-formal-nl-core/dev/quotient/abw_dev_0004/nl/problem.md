# Problem

There are 1 synthetic object kinds in this world: mav.
The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Rules
- R holds between x and x.
- If R holds between x and y, then R holds between y and x.
- If R holds between x and y and R holds between y and z, then R holds between x and z.
- R holds between x and the shift of x.
- If R holds between x and y and Good holds of x, then Good holds of y.
- If R holds between x and y, then R holds between the lift of x and the lift of y.

## Task
Invent a reusable bridge concept that captures a repeated structural pattern in the public facts and theorems.
Then propose a lemma that makes deeper hidden targets cheaper to justify under the benchmark's proof budget.
