# Examples

## Visible Facts
- Good0 holds of mav-0.
- Good1 holds of mav-0.
- Good2 holds of mav-0.
- Good0 holds of mav-1.
- Good1 holds of mav-1.
- Good2 holds of mav-1.
- R holds between mav-0 and mav-2.
- R holds between mav-0 and mav-3.

## Visible Targets
- visible_good_norm: Good0 holds of the shift of mav-0.
