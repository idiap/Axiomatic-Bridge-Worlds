# Hidden Bridge

- define SameClass(x:S0, y:S0) := R(x, y)
- define Representative0(x:S0) := norm(x) = x
- lemma good0_norm_transfer: forall x:S0. Good0(x) -> Good0(norm(x))
- lemma good1_norm_transfer: forall x:S0. Good1(x) -> Good1(norm(x))
- lemma good2_norm_transfer: forall x:S0. Good2(x) -> Good2(norm(x))
- lemma step_class: forall x:S0 y:S0. SameClass(x, y) -> SameClass(step(x), step(y))
