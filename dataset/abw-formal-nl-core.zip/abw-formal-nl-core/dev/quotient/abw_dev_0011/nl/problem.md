# Problem

The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Public Vocabulary
- Object kind: mav.
- Named object: mav-0 is a mav object.
- Named object: mav-1 is a mav object.
- Named object: mav-2 is a mav object.
- Operation: shift takes a mav object and returns a mav object.
- Operation: lift takes a mav object and returns a mav object.
- Relation: Good0 can hold of a mav object.
- Relation: Good1 can hold of a mav object.
- Relation: Good2 can hold of a mav object.
- Relation: R can hold between a mav object and a mav object.
- Relation: Tag0 can hold of a mav object.
- Relation: Tag1 can hold of a mav object.
- Relation: Tag2 can hold of a mav object.

## Rules
- R holds between x and x.
- If R holds between x and y, then R holds between y and x.
- If R holds between x and y and R holds between y and z, then R holds between x and z.
- R holds between x and the shift of x.
- If R holds between x and y and Good0 holds of x, then Good0 holds of y.
- If R holds between x and y and Good1 holds of x, then Good1 holds of y.
- If R holds between x and y and Good2 holds of x, then Good2 holds of y.
- If R holds between x and y, then R holds between the lift of x and the lift of y.

## Task
Invent a reusable bridge concept that captures a repeated structural pattern in the public facts and theorems.
Then propose a lemma that makes deeper hidden targets cheaper to justify under the benchmark's proof budget.
