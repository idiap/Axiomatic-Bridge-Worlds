# Examples

## Visible Facts
- A holds of mav-0.
- B holds of mav-0.
- A holds of mav-1.
- B holds of mav-1.
- A holds of mav-2.
- B holds of mav-2.

## Visible Targets
- visible_stable_step: A holds of the shift of mav-0 and B holds of the shift of mav-0.
