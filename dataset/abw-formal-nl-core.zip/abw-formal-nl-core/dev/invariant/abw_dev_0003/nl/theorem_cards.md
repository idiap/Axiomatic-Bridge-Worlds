# Theorem Cards

## Visible Theorems
- **ab_step**: If A holds of x and B holds of x, then A holds of the shift of x.
