# Hidden Bridge

- define StableTriple(x:S0) := A(x) & B(x) & C(x)
- lemma stable_step: forall x:S0. StableTriple(x) -> StableTriple(step(x))
