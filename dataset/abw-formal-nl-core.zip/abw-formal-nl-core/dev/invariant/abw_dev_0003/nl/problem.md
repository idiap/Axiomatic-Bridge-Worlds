# Problem

There are 1 synthetic object kinds in this world: mav.
The names are intentionally neutral so the task depends on structure, not stored background knowledge.

## Rules
- If A holds of x, then A holds of the shift of x.
- If B holds of x, then B holds of the shift of x.
- If C holds of x, then C holds of the shift of x.
- If Noise holds of x, then Noise holds of the shift of x.

## Task
Invent a reusable bridge concept that captures a repeated structural pattern in the public facts and theorems.
Then propose a lemma that makes deeper hidden targets cheaper to justify under the benchmark's proof budget.
