# Gold Informal Solution

A strong solution names the synchronized low-level state with one reusable predicate and advances it with one lemma.
- Formal definition: `define StableTriple(x:S0) := A(x) & B(x) & C(x)`
